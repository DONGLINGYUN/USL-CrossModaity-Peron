# textCNN_pytorch
使用pytorch搭建textCNN实现中文文本分类
具体描述见博客：https://blog.csdn.net/u013832707/article/details/88634197
